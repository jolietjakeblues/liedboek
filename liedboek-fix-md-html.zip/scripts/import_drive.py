#!/usr/bin/env python3
import html
import io
import json
import os
import re
import unicodedata
from pathlib import Path

import google.auth
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
SONGS = DOCS / "liedjes"
TOPICS = DOCS / "onderwerpen"
ARTICLES = DOCS / "over-liedjes"
DATA = DOCS / "_data"

GOOGLE_DOC_MIME = "application/vnd.google-apps.document"
GOOGLE_FOLDER_MIME = "application/vnd.google-apps.folder"
DRIVE_RETRIES = 5

META_RE = re.compile(
    r"^\s*\[\[liedboek\]\]\s*\n(.*?)\n\s*\[\[/liedboek\]\]\s*\n?",
    re.I | re.S,
)
NOTE_RE = re.compile(
    r"^\s*\[\[schrijfnotitie\]\]\s*\n(.*?)\n\s*\[\[/schrijfnotitie\]\]\s*\n?",
    re.I | re.S,
)
ARTICLE_META_RE = re.compile(
    r"^\s*\[\[overliedjes\]\]\s*\n(.*?)\n\s*\[\[/overliedjes\]\]\s*\n?",
    re.I | re.S,
)
SPOTIFY_RE = re.compile(
    r"\[\[spotify\]\]\s*"
    r"https?://open\.spotify\.com/(?:intl-[^/]+/)?track/([A-Za-z0-9]+)(?:\?[^\s<]*)?"
    r"\s*\[\[/spotify\]\]",
    re.I,
)

STATUS_LABELS = {
    "concept": "Concept",
    "werkversie": "Werkversie",
    "definitief": "Definitief",
}
LANGUAGE_LABELS = {
    "nl": "Nederlands",
    "en": "Engels",
    "de": "Duits",
    "fr": "Frans",
}

CONNECTIONS = [
    {
        "title": "Onderweg en thuiskomen",
        "description": "Liedjes waarin afstand, vertrekken en thuiskomen meer betekenen dan alleen een plaats op de kaart.",
        "tags": {"onderweg", "thuiskomen", "afscheid"},
    },
    {
        "title": "Wat achterblijft",
        "description": "Verlies wordt vaak zichtbaar in wat er na een vertrek, dood of afscheid nog in de kamer, het hoofd of het dagelijks leven staat.",
        "tags": {"verlies", "afscheid", "herinneringen", "dood"},
    },
    {
        "title": "Wie je bent en wat je laat zien",
        "description": "Over identiteit, zelfbeeld, maskers en het verschil tussen hoe iemand gezien wordt en wat eronder zit.",
        "tags": {"identiteit", "zelfbeeld", "authenticiteit"},
    },
    {
        "title": "Drank en gevolgen",
        "description": "Drank is hier niet alleen decor. Soms is het brandstof, uitvlucht, herinnering, grap of de rekening die later komt.",
        "tags": {"alcohol", "zelfdestructie", "schuld"},
    },
    {
        "title": "Werk, ouder worden en doorgaan",
        "description": "Liedjes over werken, tijd die voorbijgaat en doorgaan wanneer het leven minder romantisch blijkt dan vroeger.",
        "tags": {"arbeid", "ouder worden"},
    },
    {
        "title": "Muziek als leven",
        "description": "Podium, verhalen en muziek zijn niet alleen achtergrond, maar een manier om te bestaan, te ontsnappen of terug te kijken.",
        "tags": {"muziek", "podium", "verhalen"},
    },
]


def slugify(value):
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    value = value.lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or "stuk"


def first_letter(value):
    normalized = unicodedata.normalize("NFKD", value)
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii").strip()
    if not ascii_value:
        return "#"
    char = ascii_value[0].upper()
    return char if "A" <= char <= "Z" else "#"


def yes(value):
    return str(value).strip().lower() in {"ja", "yes", "true", "1", "y"}


def parse_tags(value):
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_metadata(text):
    meta = {
        "tags": [],
        "akkoorden": False,
        "buma": False,
        "jaar": "",
        "taal": "",
        "status": "",
    }
    match = META_RE.match(text)
    if not match:
        return meta, text.strip()

    for line in match.group(1).splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().lower()
        value = value.strip()
        if key in {"tags", "onderwerpen"}:
            meta["tags"] = parse_tags(value)
        elif key == "akkoorden":
            meta["akkoorden"] = yes(value)
        elif key == "buma":
            meta["buma"] = yes(value)
        elif key == "jaar":
            meta["jaar"] = value
        elif key == "taal":
            meta["taal"] = value.lower()
        elif key == "status":
            meta["status"] = value.lower()

    return meta, text[match.end():].strip()


def parse_writing_note(text):
    match = NOTE_RE.match(text)
    if not match:
        return "", text.strip()
    return match.group(1).strip(), text[match.end():].strip()


def parse_article_metadata(text):
    meta = {"titel": "", "artiest": "", "intro": ""}
    match = ARTICLE_META_RE.match(text)
    if not match:
        return meta, text.strip()

    for line in match.group(1).splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().lower()
        value = value.strip()
        if key in meta:
            meta[key] = value

    return meta, text[match.end():].strip()


def render_spotify_blocks(text):
    def replace(match):
        track_id = match.group(1)
        return (
            '\n\n<div class="spotify-embed">\n'
            '<iframe '
            'src="https://open.spotify.com/embed/track/' + track_id + '" '
            'width="100%" height="352" frameborder="0" '
            'allowfullscreen="" '
            'allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" '
            'loading="lazy" '
            'title="Spotify-player"></iframe>\n'
            '</div>\n\n'
        )
    return SPOTIFY_RE.sub(replace, text)


def service():
    credentials, _ = google.auth.default(
        scopes=["https://www.googleapis.com/auth/drive.readonly"]
    )
    return build("drive", "v3", credentials=credentials, cache_discovery=False)


def list_docs(api, folder_id):
    q = (
        f"'{folder_id}' in parents and "
        f"mimeType='{GOOGLE_DOC_MIME}' and trashed=false"
    )
    out = []
    token = None
    while True:
        response = api.files().list(
            q=q,
            spaces="drive",
            fields="nextPageToken, files(id,name,modifiedTime)",
            orderBy="name_natural",
            pageToken=token,
        ).execute(num_retries=DRIVE_RETRIES)
        out += response.get("files", [])
        token = response.get("nextPageToken")
        if not token:
            return out


def list_article_files(api, folder_id):
    q = f"'{folder_id}' in parents and trashed=false"
    out = []
    token = None
    while True:
        response = api.files().list(
            q=q,
            spaces="drive",
            fields="nextPageToken, files(id,name,mimeType,modifiedTime)",
            orderBy="name_natural",
            pageToken=token,
        ).execute(num_retries=DRIVE_RETRIES)
        for item in response.get("files", []):
            name = item["name"].lower()
            if (
                item["mimeType"] == GOOGLE_DOC_MIME
                or name.endswith(".md")
                or item["mimeType"] in {"text/markdown", "text/plain"}
            ):
                out.append(item)
        token = response.get("nextPageToken")
        if not token:
            return out


def find_folder_by_name(api, name):
    safe_name = name.replace("\\", "\\\\").replace("'", "\\'")
    q = (
        f"name='{safe_name}' and "
        f"mimeType='{GOOGLE_FOLDER_MIME}' and trashed=false"
    )
    response = api.files().list(
        q=q,
        spaces="drive",
        fields="files(id,name)",
        orderBy="modifiedTime desc",
        pageSize=20,
    ).execute(num_retries=DRIVE_RETRIES)

    folders = response.get("files", [])
    if not folders:
        return None
    if len(folders) > 1:
        print(
            f"Waarschuwing: meerdere Drive-mappen met naam '{name}' gevonden; "
            "de eerste zichtbare map wordt gebruikt."
        )
    return folders[0]["id"]


def export_text(api, file_id):
    request = api.files().export_media(fileId=file_id, mimeType="text/plain")
    buffer = io.BytesIO()
    downloader = MediaIoBaseDownload(buffer, request)
    done = False
    while not done:
        _, done = downloader.next_chunk(num_retries=DRIVE_RETRIES)
    return (
        buffer.getvalue()
        .decode("utf-8-sig")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
    )


def download_text(api, file_id):
    request = api.files().get_media(fileId=file_id)
    buffer = io.BytesIO()
    downloader = MediaIoBaseDownload(buffer, request)
    done = False
    while not done:
        _, done = downloader.next_chunk(num_retries=DRIVE_RETRIES)
    return (
        buffer.getvalue()
        .decode("utf-8-sig")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
    )


def read_article_file(api, item):
    if item["mimeType"] == GOOGLE_DOC_MIME:
        return export_text(api, item["id"])
    return download_text(api, item["id"])


def fm(value):
    return str(value).replace("\\", "\\\\").replace('"', '\\"')


def topic_link(tag):
    return (
        f'<a href="{{{{ site.baseurl }}}}/onderwerpen/{slugify(tag)}/">'
        f"{html.escape(tag)}</a>"
    )


def writing_note_html(note):
    if not note:
        return ""
    paragraphs = []
    for block in re.split(r"\n\s*\n", note.strip()):
        escaped = html.escape(block.strip()).replace("\n", "<br>\n")
        paragraphs.append(f"<p>{escaped}</p>")
    return (
        '<aside class="writing-note">\n'
        "<h2>Schrijfnotitie</h2>\n"
        + "\n".join(paragraphs)
        + "\n</aside>"
    )


def song_page(item):
    tags_html = ""
    if item["tags"]:
        links = " · ".join(topic_link(tag) for tag in item["tags"])
        tags_html = f'<p class="meta">Onderwerpen: {links}</p>'

    year_html = (
        f'<p class="meta">Jaar: {html.escape(item["jaar"])}</p>'
        if item["jaar"] else ""
    )

    language_html = ""
    if item["taal"]:
        language = LANGUAGE_LABELS.get(item["taal"], item["taal"])
        language_html = f'<p class="meta">Taal: {html.escape(language)}</p>'

    status_html = ""
    if item["status"]:
        status = STATUS_LABELS.get(item["status"], item["status"])
        status_html = f'<p class="meta">Status: {html.escape(status)}</p>'

    buma_html = (
        '<p class="meta">Dit werk is aangemeld bij BumaStemra.</p>'
        if item["buma"] else ""
    )

    note_html = writing_note_html(item["schrijfnotitie"])
    lyrics_class = "lyrics has-chords" if item["akkoorden"] else "lyrics"

    return (
        "---\n"
        "layout: song\n"
        f'title: "{fm(item["title"])}"\n'
        f'permalink: /liedjes/{item["slug"]}/\n'
        "---\n\n"
        f'<pre class="{lyrics_class}">{html.escape(item["text"])}</pre>\n\n'
        f"{note_html}\n"
        f"{tags_html}\n"
        f"{year_html}\n"
        f"{language_html}\n"
        f"{status_html}\n"
        '<p class="rights">© Joop Vanderheiden. Alle rechten voorbehouden.</p>\n'
        f"{buma_html}\n"
    )


def compact_meta(item):
    parts = []
    if item["taal"]:
        parts.append(LANGUAGE_LABELS.get(item["taal"], item["taal"]))
    if item["jaar"]:
        parts.append(html.escape(item["jaar"]))
    if item["akkoorden"]:
        parts.append("met akkoorden")
    return parts


def write_index(items):
    ordered = sorted(items, key=lambda x: x["title"].casefold())
    groups = {}
    for item in ordered:
        groups.setdefault(first_letter(item["title"]), []).append(item)

    lines = [
        "---",
        "layout: default",
        'title: "Liedjes"',
        "permalink: /liedjes/",
        "---",
        "",
        "# Liedjes",
        "",
        '<div class="song-tools">',
        '<input id="song-search" class="search" type="search" placeholder="Zoek een lied..." aria-label="Zoek een lied">',
        '<div class="song-filters" role="group" aria-label="Filter liedjes">',
        '<button type="button" class="filter is-active" data-filter="all">Alle</button>',
        '<button type="button" class="filter" data-filter="nl">Nederlands</button>',
        '<button type="button" class="filter" data-filter="en">Engels</button>',
        '<button type="button" class="filter" data-filter="chords">Met akkoorden</button>',
        "</div>",
        "</div>",
        "",
        '<nav class="alphabet" aria-label="Alfabet">',
    ]
    for letter in groups:
        lines.append(f'<a href="#letter-{letter.lower()}">{letter}</a>')
    lines += ["</nav>", "", '<div id="song-list" class="song-groups">']

    for letter, group in groups.items():
        lines += [
            f'<section class="song-group" data-letter="{letter}">',
            f'<h2 id="letter-{letter.lower()}" class="letter-heading">{letter}</h2>',
            '<ul class="song-list">',
        ]
        for item in group:
            title = html.escape(item["title"])
            folded = html.escape(item["title"].casefold(), quote=True)
            tags_search = html.escape(" ".join(item["tags"]).casefold(), quote=True)
            language = html.escape(item["taal"], quote=True)
            chords = "true" if item["akkoorden"] else "false"
            meta_bits = [html.escape(part) for part in compact_meta(item)]
            if item["tags"]:
                meta_bits.extend(topic_link(tag) for tag in item["tags"][:3])

            lines += [
                (
                    f'<li class="song-list-item" data-title="{folded}" '
                    f'data-tags="{tags_search}" data-language="{language}" '
                    f'data-chords="{chords}">'
                ),
                f'<a class="song-title" href="{{{{ site.baseurl }}}}/liedjes/{item["slug"]}/">{title}</a>',
            ]
            if meta_bits:
                lines.append(
                    '<div class="song-summary">' + " · ".join(meta_bits) + "</div>"
                )
            lines.append("</li>")
        lines += ["</ul>", "</section>"]

    lines += [
        "</div>",
        '<p id="song-empty" class="song-empty" hidden>Geen liedjes gevonden.</p>',
        "",
        '<script src="{{ site.baseurl }}/assets/search.js"></script>',
        "",
    ]
    (SONGS / "index.md").write_text("\n".join(lines), encoding="utf-8")


def write_chords(items):
    selected = [x for x in items if x["akkoorden"]]
    lines = [
        "---",
        "layout: default",
        'title: "Met akkoorden"',
        "permalink: /akkoorden/",
        "---",
        "",
        "# Met akkoorden",
        "",
    ]
    if selected:
        for item in sorted(selected, key=lambda x: x["title"].casefold()):
            lines.append(
                f'- [{item["title"]}]({{{{ site.baseurl }}}}/liedjes/{item["slug"]}/)'
            )
    else:
        lines.append("Nog geen liedjes gemarkeerd als lied met akkoorden.")
    lines.append("")
    (DOCS / "akkoorden.md").write_text("\n".join(lines), encoding="utf-8")


def write_topics(items):
    TOPICS.mkdir(parents=True, exist_ok=True)
    for path in TOPICS.glob("*.md"):
        path.unlink()

    by_topic = {}
    for item in items:
        for tag in item["tags"]:
            by_topic.setdefault(tag, []).append(item)

    overview = [
        "---",
        "layout: default",
        'title: "Onderwerpen"',
        "permalink: /onderwerpen/",
        "---",
        "",
        "# Onderwerpen",
        "",
    ]

    if not by_topic:
        overview.append("Nog geen onderwerpen toegevoegd.")
    else:
        for topic in sorted(by_topic, key=str.casefold):
            slug = slugify(topic)
            overview.append(
                f'- [{topic}]({{{{ site.baseurl }}}}/onderwerpen/{slug}/)'
            )
            page = [
                "---",
                "layout: default",
                f'title: "{fm(topic)}"',
                f"permalink: /onderwerpen/{slug}/",
                "---",
                "",
                f"# {topic}",
                "",
            ]
            for item in sorted(by_topic[topic], key=lambda x: x["title"].casefold()):
                page.append(
                    f'- [{item["title"]}]({{{{ site.baseurl }}}}/liedjes/{item["slug"]}/)'
                )
            page.append("")
            (TOPICS / f"{slug}.md").write_text("\n".join(page), encoding="utf-8")

    (DOCS / "onderwerpen.md").write_text(
        "\n".join(overview) + "\n",
        encoding="utf-8",
    )


def write_connections(items):
    lines = [
        "---",
        "layout: default",
        'title: "Dwarsverbanden"',
        "permalink: /dwarsverbanden/",
        "---",
        "",
        "# Dwarsverbanden",
        "",
        '<p class="connections-intro">'
        "Onderwerpen benoemen waar een lied over gaat. Dwarsverbanden laten zien "
        "welke grotere lijnen door verschillende liedjes heen lopen."
        "</p>",
        "",
    ]

    written = 0
    for connection in CONNECTIONS:
        matching = []
        wanted = {tag.casefold() for tag in connection["tags"]}
        for item in items:
            item_tags = {tag.casefold() for tag in item["tags"]}
            matched = sorted(item_tags & wanted)
            if matched:
                matching.append((item, matched))

        if len(matching) < 2:
            continue

        written += 1
        lines += [
            '<section class="connection">',
            f'<h2>{html.escape(connection["title"])}</h2>',
            f'<p class="connection-description">{html.escape(connection["description"])}</p>',
            '<ul class="connection-songs">',
        ]
        for item, matched in sorted(matching, key=lambda x: x[0]["title"].casefold()):
            title = html.escape(item["title"])
            matched_text = " · ".join(html.escape(tag) for tag in matched)
            lines += [
                "<li>",
                f'<a href="{{{{ site.baseurl }}}}/liedjes/{item["slug"]}/">{title}</a>',
                f'<span class="connection-match">{matched_text}</span>',
                "</li>",
            ]
        lines += ["</ul>", "</section>", ""]

    if not written:
        lines.append(
            "Er zijn nog te weinig getagde liedjes om betekenisvolle dwarsverbanden te tonen."
        )

    (DOCS / "dwarsverbanden.md").write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )


def article_page(item):
    return (
        "---\n"
        "layout: article\n"
        f'title: "{fm(item["title"])}"\n'
        f'artist: "{fm(item["artist"])}"\n'
        f'intro: "{fm(item["intro"])}"\n'
        f'permalink: /over-liedjes/{item["slug"]}/\n'
        "---\n\n"
        f'{item["text"].strip()}\n'
    )


def write_article_index(items):
    lines = [
        "---",
        "layout: default",
        'title: "Over liedjes"',
        "permalink: /over-liedjes/",
        "---",
        "",
        "# Over liedjes",
        "",
        "Persoonlijke stukken over liedjes die iets openbreken, en over wat daarin raakt aan mijn eigen schrijven.",
        "",
        '<div class="article-list">',
    ]

    if not items:
        lines.append("<p>Nog geen stukken gepubliceerd.</p>")
    else:
        for item in sorted(items, key=lambda x: x["title"].casefold()):
            title = html.escape(item["title"])
            artist = html.escape(item["artist"])
            intro = html.escape(item["intro"])
            display_title = f"{title} — {artist}" if artist else title
            lines += [
                '<article class="article-card">',
                f'<h2><a href="{{{{ site.baseurl }}}}/over-liedjes/{item["slug"]}/">{display_title}</a></h2>',
            ]
            if intro:
                lines.append(f'<p>{intro}</p>')
            lines.append("</article>")

    lines += ["</div>", ""]
    (ARTICLES / "index.md").write_text("\n".join(lines), encoding="utf-8")


def write_articles(api):
    ARTICLES.mkdir(parents=True, exist_ok=True)
    for path in ARTICLES.glob("*.md"):
        path.unlink()

    folder_id = os.environ.get("GOOGLE_DRIVE_ARTICLES_FOLDER_ID", "").strip()
    if not folder_id:
        folder_id = find_folder_by_name(api, "overliedjes")

    if not folder_id:
        print(
            "Waarschuwing: Drive-map 'overliedjes' is niet zichtbaar. "
            "Deel de map met dezelfde service-account als 'gepubliceerd'."
        )
        write_article_index([])
        return []

    source_files = list_article_files(api, folder_id)
    items = []
    used_slugs = set()

    for source in source_files:
        raw = read_article_file(api, source)
        meta, body = parse_article_metadata(raw)

        # Markdown en ruwe HTML blijven verder volledig intact.
        # Alleen de optionele [[spotify]] shorthand wordt omgezet.
        body = render_spotify_blocks(body)

        doc_name = source["name"].strip()
        if doc_name.lower().endswith(".md"):
            doc_name = doc_name[:-3].rstrip()

        title = (meta["titel"] or doc_name).strip()
        artist = meta["artiest"].strip()

        if not artist and " — " in title:
            maybe_title, maybe_artist = title.rsplit(" — ", 1)
            if maybe_title.strip() and maybe_artist.strip():
                title = maybe_title.strip()
                artist = maybe_artist.strip()

        slug = slugify(title)
        if slug in used_slugs:
            slug = f"{slug}-{source['id'][:6].lower()}"
        used_slugs.add(slug)

        item = {
            "title": title,
            "slug": slug,
            "artist": artist,
            "intro": meta["intro"].strip(),
            "text": body.strip(),
        }
        items.append(item)

        (ARTICLES / f"{slug}.md").write_text(
            article_page(item),
            encoding="utf-8",
        )

    write_article_index(items)
    return items


def main():
    folder_id = os.environ["GOOGLE_DRIVE_FOLDER_ID"]
    SONGS.mkdir(parents=True, exist_ok=True)
    DATA.mkdir(parents=True, exist_ok=True)

    for path in SONGS.glob("*.md"):
        if path.name != "index.md":
            path.unlink()

    api = service()
    docs = list_docs(api, folder_id)

    items = []
    used_slugs = set()

    for doc in docs:
        title = doc["name"].strip()
        slug = slugify(title)
        if slug in used_slugs:
            slug = f"{slug}-{doc['id'][:6].lower()}"
        used_slugs.add(slug)

        meta, remainder = parse_metadata(export_text(api, doc["id"]))
        schrijfnotitie, body = parse_writing_note(remainder)
        item = {
            "title": title,
            "slug": slug,
            "text": body,
            "schrijfnotitie": schrijfnotitie,
            **meta,
        }
        items.append(item)

        (SONGS / f"{slug}.md").write_text(song_page(item), encoding="utf-8")

    write_index(items)
    write_chords(items)
    write_topics(items)
    write_connections(items)
    articles = write_articles(api)

    public_search = [
        {
            "title": x["title"],
            "url": f"/liedjes/{x['slug']}/",
            "tags": x["tags"],
            "taal": x["taal"],
            "status": x["status"],
            "jaar": x["jaar"],
            "akkoorden": x["akkoorden"],
        }
        for x in items
    ]
    (DATA / "songs.json").write_text(
        json.dumps(public_search, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(
        f"Gesynchroniseerd: {len(items)} lied(en), "
        f"{len(articles)} stuk(ken) over liedjes."
    )


if __name__ == "__main__":
    main()
